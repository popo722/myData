#import wiringpi as wp
import time
import pygame.mixer
import RPi.GPIO as GPIO
import threadinig


# Sound Setting
pygame.mixer.init()
#pygame.mixer.music.load("/usr/share/sounds/alsa/Rear_Center.wav")
pygame.mixer.music.load("./korosuke1.mp3")

#serbo Moter Settings
GPIO.setmode(GPIO.BCM)

touch_pin = 17
gp_out_r  = 4
gp_out_l  = 26
GPIO.setup(gp_out_r, GPIO.OUT)
GPIO.setup(gp_out_l, GPIO.OUT)
GPIO.setup(touch_pin, GPIO.IN)
servo_r = GPIO.PWM(gp_out_r, 50)
servo_l = GPIO.PWM(gp_out_l, 50) 
servo_r.start(0.0)
servo_l.start(0.0)

srclist =["./korosuke1.mp3", "./korosuke2.mp3", "./korosuke3.mp3", "./korosuke2.mp3"]
def play1(id):
    pygame.mixer.music.load(srclist[id])
    pygame.mixer.music.play(1)

def move_arm_r():
    servo_r.ChangeDutyCycle(2.5)
    time.sleep(0.5)
    servo_r.ChangeDutyCycle(12.0)
    time.sleep(0.5)
    servo_r.start(0.0)

def move_arm_l():
    servo_l.ChangeDutyCycle(2.5)
    time.sleep(0.5)
    servo_l.ChangeDutyCycle(12.0)
    time.sleep(0.5)
    servo_l.start(0.0)

while True:
    #status = wp.digitalRead(pin)
    status  = GPIO.input(touch_pin)
    print( "read=", status )
    if (status) :
        pygame.mixer.music.play(1)
        print( "hight" )
        thread1 = threading.Thread(target=move_arm_l)
        #move_arm_r()
        thread1.start()
        time.sleep(1)
    time.sleep(1)


GPIO.cleanup()
