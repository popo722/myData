#import wiringpi as wp
import time
import pygame.mixer
#import RPi.GPIO as GPIO

# Sound Setting
pygame.mixer.init()
#pygame.mixer.music.load("/home/pi/src/py/touch/korosuke3.mp3")
#pygame.mixer.music.play()


srclist =["./korosuke1.mp3", "./korosuke2.mp3", "./korosuke3.mp3", "./korosuke2.mp3"]
def play1(id):
    src = srclist[id]
    #print src
    pygame.mixer.music.load(src)
    pygame.mixer.music.play(1)

play1(2)
time.sleep(3)
